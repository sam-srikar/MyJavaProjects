/**
 * A class representing a savings account with specific functionalities such as
 * interest rate and adding interest.
 */

public class SavingsAccount extends BankAccount {
    // The monthly interest rate for the savings account.
    private double interestRate;

    // Constructs a savings account defining a monthly interest rate and no balance.
    public SavingsAccount(double rate) {
        super();
        this.interestRate = rate;
    }

    // Constructs a savings account defining a monthly interest rate and a given
    // balance.
    public SavingsAccount(double rate, double initialBalance) {
        super(initialBalance);
        this.interestRate = rate;
    }

    // Adds the earned interest to the account balance.
    public void addInterest() {
        double interest = balance * interestRate;
        deposit(interest);
    }

    // Closes the savings account by transferring its balance to another account.
    public void close(BankAccount other) {
        transfer(balance, other);
        balance = 0;
    }
}
