/**
 * A class representing a checking account with specific functionalities such as
 * transaction count,
 * transaction fee, maintenance fee, and closing fee.
 */

public class CheckingAccount extends BankAccount {
    // The transaction count
    private int tc;
    // Constants for free transactions, transaction fee, closing fee, and
    // maintenance fee.
    private static final int FREE_TRANSACTIONS = 3;
    private static final double TRANSACTION_FEE = 2.0;
    private static final double CLOSING_FEE = 5.0;
    private static final double MAINTENANCE_FEE = 10.0;
    //public double balance;

    // Constructs a checking account with no balance and initializes the transaction
    // count.
    public CheckingAccount() {
        super();
        this.tc = 0;
    }

    // Constructs a checking account with a given balance and initializes the
    // transaction count.
    public CheckingAccount(double initialBalance) {
        super(initialBalance);
        this.tc = 0;
    }

    // Deposits money into the checking account.
    public void deposit(double amount) {
        super.deposit(amount);
        tc++;
        if (tc > FREE_TRANSACTIONS) {
            super.withdraw(TRANSACTION_FEE);
        }
    }

    // Withdraws money from the checking account.
    public void withdraw(double amount) {
        super.withdraw(amount);
        tc++;
        if (tc > FREE_TRANSACTIONS) {
            super.withdraw(TRANSACTION_FEE);
        }
    }

    // Charges the maintenance fee and resets the transaction count for a new month.
    public void deductMaintenanceFee() {
        super.withdraw(MAINTENANCE_FEE);
        tc = 0;
    }

    // Closes the checking account by transferring its balance to another account.
    public void close(BankAccount other) {
        tc = 0;
        super.withdraw(CLOSING_FEE);
        transfer(balance, other);
        balance = 0;
    }
}
