/**
 * An abstract class representing a bank account with basic functions.
 */
public abstract class BankAccount {
    // The balance of the bank account.
    public double balance;

    // Constructs an empty bank account with a zero balance.
    public BankAccount() {
        this.balance = 0;
    }

    // Constructs a bank account with a given balance.
    public BankAccount(double initialBalance) {
        this.balance = initialBalance;
    }

    // Deposits money into the bank account.
    public void deposit(double amount) {
        balance += amount;
    }

    // Withdraws money from the bank account.
    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
        } else {
            System.out.println("Insufficient funds");
        }
    }

    // Gets the current balance of the bank account.
    public double getBalance() {
        return balance;
    }

    // Transfers money from this bank account to another account.
    public void transfer(double amount, BankAccount other) {
        if (amount <= balance) {
            withdraw(amount);
            other.deposit(amount);
        } else {
            System.out.println("Insufficient funds");
        }
    }

    // Closes the bank account by transferring its balance to another account.
    public abstract void close(BankAccount other);
}
